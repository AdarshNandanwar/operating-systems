#ifndef __PARSE_FLOAT_WRAPPER_H_
#define __PARSE_FLOAT_WRAPPER_H_

extern float getFloat(char *, int);

#endif