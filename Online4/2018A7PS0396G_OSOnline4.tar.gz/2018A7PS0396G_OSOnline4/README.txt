What all completly working?
Everything

What all completed by not working / not tested?
-

What all not attempted?
-