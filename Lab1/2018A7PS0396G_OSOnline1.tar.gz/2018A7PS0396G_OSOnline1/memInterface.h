#ifndef RESULT_STRUCT_HEADER
#define RESULT_STRUCT_HEADER

struct result{
    int remCount;
    int attemptCount;
};

#endif