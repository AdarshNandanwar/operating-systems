#ifndef CRICKET_HEADER
#define CRICKET_HEADER

int shmid;

extern void process_umpire();

extern void process_team(int);

#endif